# 06 · Lipoplex surface targeting

Which receptor the lipoplex should be decorated against, and which antibody reagents can actually
bind it on an intact cell.

## Question

The project bibliography («Antibodies on the lipoplex») proposed two-level targeting — a BBB handle
plus a nociceptor handle — with `TfR + P2X3` and `TfR + TRPV1` as candidate pairs. TfR and TRPV1 were
covered by the earlier `antibody_assessment.md`; P2X3, NaV1.7, NaV1.8, TRPA1 and INSR were not.

## Method

Reviewed UniProt entries for human / rat / mouse were resolved by `gene_exact` + `organism_id`
(**not** by recalled accession — three recalled accessions were wrong and were caught by a length
check). Per target: transmembrane-segment count, extracellular loop count and total length,
extracellular fraction, largest single exposed loop. Cross-species identity was computed twice —
whole protein and concatenated extracellular segments only — by Needleman–Wunsch with traceback.
The **difference** between the two is the discriminating quantity, since a reagent is raised against
the ectodomain rather than the average protein.

## Result

`TfR + P2X3` is supported; `TfR + TRPV1` is not. P2X3: **70.3% extracellular**, one contiguous
279-residue loop, ectodomain **95.7%** identical human-vs-rat (*above* its 94.0% whole-protein
identity). TRPV1: 6.7% across four loops, largest 32 aa, ectodomain identity collapses to 53.4%.
INSR is a credible second BBB handle (66.9%, 95.5%) without TfR's species restriction — TfR's own
ectodomain is only 75.3% conserved, which is why anti-TfR clones are not interchangeable between
species.

The reagent shortlist excludes **Alomone APR-016**, the field's most-cited P2X3 antibody: its vendor
epitope `(C)VEKQSTDSGAYSIGH` sits at aa 383–397, the cytoplasmic tail, outside the 44–322 ectodomain.
It cannot bind a live cell. The listed peptide is also the *rat* sequence (human: `AEKQSTDSGAFSIGH`).
A registry-wide screen (103 records) identified two reagents with immunogen sequences verifiable
against the ectodomain: **A10232** (AB_2757757, aa 44–317, rat-listed) and **HPA057776**
(AB_2683526, aa 184–260, human-listed). These carry stronger epitope evidence than **PA5-77682**
(AB_2736292), whose immunogen is undisclosed. None is validated for live-cell surface binding.

## Limitation

Zero catalogue numbers appeared in a surface / unpermeabilized context across 97 screened
open-access papers. P2X3 has never been used as a nanoparticle-targeting ligand: a novelty claim
requiring validation, not a citable precedent. Topology annotation is not structure, and ectodomain
identity is not epitope identity.

## Files

| File | Contents |
|---|---|
| `LIPOPLEX_TARGETING.md` | Full assessment with method, tiers, and caveats |
| `lipoplex_targeting_assessment.csv` | Decision table — topology + conservation + literature counts + tier |
| `lipoplex_targeting_topology_allspecies.csv` | Per-target, per-species membrane topology |
| `lipoplex_targeting_conservation.csv` | Full-protein vs ectodomain identity, human vs rat and mouse |
| `p2x3_registry_epitope_screen.csv` | Published immunogens of all registry reagents, located in-sequence and tested against the ectodomain |
| `antibody_shortlist_p2x3.csv` | Reagent shortlist; same columns as `antibody_shortlist.csv` so the two concatenate |
| `lipoplex_targeting_assessment.png` | Two-panel figure — reachable surface, and epitope transferability |
| `lipoplex_wetlab_handout.pdf` | Bench handout: rationale, shortlist, ordered protocol, limitations |
| `uniprot_targets.json` | Raw UniProt records the analysis was computed from |
